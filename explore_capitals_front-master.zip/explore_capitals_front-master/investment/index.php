<?php
const pageName = "Investment Plans";
const rootDir = "/home/multistream6/domains/explorecapitals.online/public_html/";
require_once (rootDir.'include/config.php');
require_once (rootDir.'partials/header.php');
require_once (rootDir.'investment/breadcrumbs.php');
require_once (rootDir.'investment/investment-plans.php');
require_once (rootDir.'investment/modal.php');

require_once (rootDir.'partials/footer.php');
