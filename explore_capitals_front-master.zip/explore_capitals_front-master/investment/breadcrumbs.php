<section class="breadcrumbs" style="background-image: url(/asset/theme1/images/breadcrumbs/breadcrumbs.jpg);">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center text-capitalize">
            <h2>Investment plans</h2>
            <ol>
                <li><a href="/">Home</a></li>
                <li>Investment plan</li>
            </ol>
        </div>
    </div>
</section>