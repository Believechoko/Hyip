<div class="modal fade" id="invest" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <form action="https://hyipmax.springsoftit.com/demo/investmentplan/invest" method="post">
            <input type="hidden" name="_token" value="TfF30Aiq6Xru76A471los5uWsgMzrzPlIyCgXOG2">                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Invest now</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="form-group">
                            <label for="">Invest amount</label>
                            <input type="text" name="amount" class="form-control">
                            <input type="hidden" name="plan_id" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="sp_btn sp_btn_secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="sp_btn sp_theme_btn">Invest now</button>
                </div>
            </div>
        </form>
    </div>
</div>