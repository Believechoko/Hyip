<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs" style="background-image: url(/asset/theme1/images/breadcrumbs/breadcrumbs.jpg);">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center text-capitalize">
            <h2>About</h2>
            <ol>
                <li><a href="/index.htm">Home</a></li>
                <li>About</li>
            </ol>
        </div>

    </div>
</section>
<!-- End Breadcrumbs -->