<!-- ======= Breadcrumbs ======= -->
<section class="breadcrumbs" style="background-image: url(/asset/theme1/images/breadcrumbs/breadcrumbs.jpg);">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center text-capitalize">
            <h2>Contact</h2>
            <ol>
                <li><a href="/">Home</a></li>
                <li>Contact</li>
            </ol>
        </div>

    </div>
</section>
<!-- End Breadcrumbs -->