<section class="s-pt-100 s-pb-100">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12 text-center">
                <div class="site-header">
                    <h2 class="site-title">Form Submitted</h2>
                </div>
                <div class="py-4 rounded text-muted my-5 shadow-lg">
                    Thanks for your message, wi will get in torch with you shortly
                </div>
            </div>
        </div>
