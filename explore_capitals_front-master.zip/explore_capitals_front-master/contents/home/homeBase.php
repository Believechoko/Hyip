<?php

namespace contents\home;

class homeBase
{
    public $siteName = 'Explore Capitals';
}